# COTL Characters

COTL Characters adds AI-powered Character Mode conversations to Cult of the Lamb followers. It is packaged for direct GitHub download: download the release zip, unzip it, then double-click the installer.

## Quick Install

1. Install Cult of the Lamb.
2. Install a modded profile with BepInEx and COTL_API separately.
3. Download COTL_Characters-0.1.0-direct-install.zip from GitHub Releases.
4. Right-click the zip and choose Extract All.
5. Open the extracted folder.
6. Double-click Install_COTL_Characters.cmd.
7. Choose your Thunderstore or r2modman profile folder when asked.
8. Start the game from that same modded profile.

No API keys are included. BepInEx, COTL_API, and game files are not included. The first launch will guide you through AI provider setup in game.

## What It Adds

- In-game Character Mode conversations with followers.
- Per-character awareness settings for traits, cult details, current events, world state, lore, and long-term chat memory.
- Short, Medium, and Long reply length controls.
- Player-written lore for individual characters.
- Tournament Ledger support.
- Character-safe invocations for cult faith and vanilla role cleanup.
- Provider setup for OpenAI, OpenAI-compatible endpoints, Anthropic, Gemini, LM Studio, and Ollama-compatible local endpoints.
- Optional internet access for eligible character replies.

## Keyboard Controls

- F7 while paused: open or close the Invocations menu.
- F8 while paused: open or close the full Tournament Ledger.
- F8 while unpaused: show or hide the current tournament match overlay.
- F9 while paused: open or close the Internet Access panel.

## Requirements

- Windows.
- Cult of the Lamb.
- BepInExPack CultOfTheLamb 5.4.2101, installed separately.
- COTL_API 0.3.3, installed separately.
- .NET 10 runtime for the included sidecar process.
- An AI provider key or local AI endpoint, unless you only use local providers that do not require a key.

## AI Provider Setup

After installation, launch the game from the modded profile. The AI Provider Setup prompt appears until setup is usable.

Use Find, Test & Save Setup. This tests provider and model settings through the same sidecar path used by character conversations.

Manual configuration is also possible at:

BepInEx/config/COTL_AL_NPCs/AiProvider.json

Never share files containing your API keys.

## Troubleshooting

- If the mod does not load, make sure you installed into the same profile you use to launch the game.
- If the installer cannot find a profile automatically, choose the folder that contains the BepInEx folder.
- If AI replies do not work, finish the in-game AI Provider Setup prompt.
- If sidecar errors appear, install the .NET 10 runtime and confirm BepInEx/plugins/COTL_AL_NPCs/sidecar exists.
- If COTL_API is missing, install it separately into the same modded profile.

## AI-Assisted Creation Disclosure

This mod and GitHub release package were partially created with the assistance of Generative AI for code changes, refactoring, documentation, and release packaging.

AI model vendor used: OpenAI.

## Credits

- Deamon_Blue
