# COTL Characters Install Guide

This is the manual install path:

1. Install BepInEx and COTL_API separately in your Cult of the Lamb modded profile.
2. Extract this archive.
3. Open the plugins folder.
4. Copy the COTL_AL_NPCs folder.
5. Paste it into your modded profile's BepInEx/plugins folder.
6. Launch the game from that same profile.

## Picking the right folder

Choose the profile folder that contains BepInEx. Common examples:

- Thunderstore Mod Manager profile folder
- r2modman profile folder
- A manual Cult of the Lamb folder that already has BepInEx installed

You are copying:

BepInEx/plugins/COTL_AL_NPCs/

into the selected profile.

## After install

Use the in-game AI Provider Setup prompt. No provider keys, BepInEx files, COTL_API files, game files, or installer scripts are included in this release.
