# COTL Characters

COTL Characters adds AI-powered Character Mode conversations to Cult of the Lamb followers.

This Nexus package is for manual installation into a modded BepInEx profile. It does not include Cult of the Lamb, BepInEx, COTL_API, game assemblies, provider accounts, or API keys.

This Nexus build intentionally does not include installer scripts. It is a manual-install archive to keep the upload simple and transparent.

## Requirements

- Windows.
- Cult of the Lamb.
- BepInExPack CultOfTheLamb 5.4.2101, installed separately.
- COTL_API 0.3.3, installed separately.
- .NET 10 runtime for the included sidecar process.
- An AI provider key or local AI endpoint, unless you only use local providers that do not require a key.

## Quick Install

1. Install Cult of the Lamb.
2. Install BepInEx and COTL_API separately.
3. Download and extract this archive.
4. Open the plugins folder.
5. Copy the COTL_AL_NPCs folder.
6. Paste it into your modded profile's BepInEx/plugins folder.
7. Start the game from that same profile.

## Manual Install

1. Extract this archive.
2. Open the plugins folder.
3. Copy the COTL_AL_NPCs folder.
4. Paste it into your modded profile's BepInEx/plugins folder.
5. Launch Cult of the Lamb from that same profile.

## What It Adds

- In-game Character Mode conversations with followers.
- Per-character awareness settings for traits, cult details, current events, world state, lore, and long-term chat memory.
- Short, Medium, and Long reply length controls.
- Player-written lore for individual characters.
- Tournament Ledger support.
- Character-safe invocations for cult faith and vanilla role cleanup.
- Provider setup for OpenAI, OpenAI-compatible endpoints, Anthropic, Gemini, LM Studio, and Ollama-compatible local endpoints.
- Optional internet access for eligible character replies.

## Keyboard Controls

- F7 while paused: open or close the Invocations menu.
- F8 while paused: open or close the full Tournament Ledger.
- F8 while unpaused: show or hide the current tournament match overlay.
- F9 while paused: open or close the Internet Access panel.

## AI Provider Setup

After installation, launch the game from the modded profile. The AI Provider Setup prompt appears until setup is usable.

Use Find, Test & Save Setup. This tests provider and model settings through the same sidecar path used by character conversations.

Manual configuration is also possible at:

BepInEx/config/COTL_AL_NPCs/AiProvider.json

This hotfix no longer stores pasted provider keys in the mod manager profile. If you used an older release and have BepInEx/config/COTL_AL_NPCs/AiProviderKey.txt, delete that file before sharing or syncing a profile. Rotate the provider key if that profile was already shared.

## Reset or Change API Key

Use the Reset button in the in-game AI Provider Setup panel when it is visible.

Manual reset:

1. Close the game.
2. Open your modded profile folder.
3. Open BepInEx/config/COTL_AL_NPCs/.
4. Delete AiProvider.json, AiProviderKey.txt, and LAST_PROVIDER_SETUP_TEST.txt if they exist.
5. Update or delete the matching Windows user environment variable: OPENAI_API_KEY, OPENROUTER_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, or AI_PROVIDER_API_KEY.
6. Relaunch the game. The AI Provider Setup panel should appear again.

Thunderstore/r2modman profiles are usually under Thunderstore Mod Manager/DataFolder/CultOfTheLamb/profiles/<ProfileName>/ or r2modmanPlus-local/CultOfTheLamb/profiles/<ProfileName>/.

## AI-Assisted Creation Disclosure

This mod and Nexus package were partially created with the assistance of Generative AI for code changes, refactoring, documentation, and release packaging.

AI model vendor used: OpenAI.

## Credits

- Deamon_Blue
