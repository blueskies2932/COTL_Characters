# Changelog

## 0.1.3

- Security hotfix: AI provider setup no longer stores pasted API keys in the mod manager profile.
- Removed generated and packaged provider setup command/script files from the release.
- Existing users should delete BepInEx/config/COTL_AL_NPCs/AiProviderKey.txt before sharing or syncing a profile.
- Initial character-only Thunderstore release candidate.
- Added Character Mode follower conversations.
- Added per-character awareness and reply length controls.
- Added Tournament Ledger support.
- Added Invocations.
- Added user-configurable AI provider setup.
- Added sidecar runtime packaging.
