# Changelog

## 0.1.4

- Fixed world-state sanitation context so a full in-game sanitation gauge is described as clean instead of hazardous/dirty.
