@echo off
setlocal
title COTL Characters Installer
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install_COTL_Characters.ps1"
echo.
pause