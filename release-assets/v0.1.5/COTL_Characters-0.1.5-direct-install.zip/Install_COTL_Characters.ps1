$ErrorActionPreference = "Stop"

function Write-Step([string]$message) {
    Write-Host ""
    Write-Host $message -ForegroundColor Cyan
}

function Find-CandidateProfiles {
    $roots = New-Object System.Collections.Generic.List[string]
    $appData = [Environment]::GetFolderPath("ApplicationData")
    foreach ($path in @(
        (Join-Path $appData "Thunderstore Mod Manager\DataFolder\COTL\profiles"),
        (Join-Path $appData "Thunderstore Mod Manager\DataFolder\CultOfTheLamb\profiles"),
        (Join-Path $appData "r2modmanPlus-local\CultOfTheLamb\profiles"),
        (Join-Path $appData "r2modmanPlus-local\COTL\profiles"))) {
        if (Test-Path -LiteralPath $path) {
            $roots.Add($path)
        }
    }

    $profiles = New-Object System.Collections.Generic.List[string]
    foreach ($root in $roots) {
        Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
            if (Test-Path -LiteralPath (Join-Path $_.FullName "BepInEx")) {
                $profiles.Add($_.FullName)
            }
        }
    }
    return @($profiles | Sort-Object -Unique)
}

function Select-FolderWithDialog {
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = "Select your modded Cult of the Lamb profile folder. Pick the folder that contains BepInEx."
        $dialog.ShowNewFolderButton = $false
        $result = $dialog.ShowDialog()
        if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
            return $dialog.SelectedPath
        }
    }
    catch {
        Write-Host "Folder picker was not available: $($_.Exception.Message)" -ForegroundColor Yellow
    }
    return ""
}

function Normalize-ProfileRoot([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) {
        return ""
    }
    $full = [System.IO.Path]::GetFullPath($path.Trim('" '))
    if ((Split-Path -Leaf $full) -ieq "BepInEx") {
        return Split-Path -Parent $full
    }
    return $full
}

function Copy-DirectoryContents([string]$source, [string]$destination) {
    if (-not (Test-Path -LiteralPath $source)) {
        throw "Missing source folder: $source"
    }
    New-Item -ItemType Directory -Force -Path $destination | Out-Null
    Copy-Item -Path (Join-Path $source "*") -Destination $destination -Recurse -Force
}

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$payloadPlugins = Join-Path $packageRoot "plugins"
$payloadPlugin = Join-Path $payloadPlugins "COTL_AL_NPCs\COTL_AL_NPCs.dll"

Write-Host "COTL Characters Installer" -ForegroundColor Green
Write-Host "This installer copies the mod into a BepInEx Cult of the Lamb profile."

if (-not (Test-Path -LiteralPath $payloadPlugin)) {
    throw "This installer cannot find the packaged mod files. Extract the release zip first, then run Install_COTL_Characters.cmd from the extracted folder."
}

$profiles = Find-CandidateProfiles
$selected = ""
if ($profiles.Count -gt 0) {
    Write-Step "Detected mod profiles:"
    for ($i = 0; $i -lt $profiles.Count; $i++) {
        Write-Host ("[{0}] {1}" -f ($i + 1), $profiles[$i])
    }
    Write-Host "[B] Browse for a folder"
    Write-Host ""
    $choice = Read-Host "Choose a profile number, or B to browse"
    if ($choice -match "^\d+$") {
        $index = [int]$choice - 1
        if ($index -ge 0 -and $index -lt $profiles.Count) {
            $selected = $profiles[$index]
        }
    }
}

if ([string]::IsNullOrWhiteSpace($selected)) {
    Write-Step "Select the profile folder"
    $selected = Select-FolderWithDialog
}

if ([string]::IsNullOrWhiteSpace($selected)) {
    Write-Host ""
    $selected = Read-Host "Paste the full path to your modded profile folder"
}

$targetRoot = Normalize-ProfileRoot $selected
if ([string]::IsNullOrWhiteSpace($targetRoot)) {
    throw "No install folder was selected."
}

Write-Step "Installing to:"
Write-Host $targetRoot

$targetPlugins = Join-Path $targetRoot "BepInEx\plugins"
New-Item -ItemType Directory -Force -Path $targetPlugins | Out-Null
Copy-DirectoryContents $payloadPlugins $targetPlugins

$installedDll = Join-Path $targetRoot "BepInEx\plugins\COTL_AL_NPCs\COTL_AL_NPCs.dll"
$installedSidecar = Join-Path $targetRoot "BepInEx\plugins\COTL_AL_NPCs\sidecar\CotlAiNpcSidecar.exe"
if (-not (Test-Path -LiteralPath $installedDll)) {
    throw "Install did not create the plugin DLL at $installedDll"
}
if (-not (Test-Path -LiteralPath $installedSidecar)) {
    throw "Install did not create the sidecar runtime at $installedSidecar"
}

Write-Step "Install complete."
Write-Host "Launch Cult of the Lamb from this same modded profile."
Write-Host "If the AI Provider Setup prompt appears in game, finish setup there."

$cotlApi = Get-ChildItem -LiteralPath (Join-Path $targetRoot "BepInEx\plugins") -Recurse -Filter "COTL_API.dll" -ErrorAction SilentlyContinue | Select-Object -First 1
if ($null -eq $cotlApi) {
    Write-Host ""
    Write-Host "Note: I did not find COTL_API.dll in this profile. Install COTL_API 0.3.3 if the mod does not load." -ForegroundColor Yellow
}

Write-Host ""