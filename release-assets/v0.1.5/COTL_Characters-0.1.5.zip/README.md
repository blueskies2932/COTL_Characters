# COTL Characters

Give your Cult of the Lamb followers configurable AI-powered character conversations, memory, lore, and cult-aware reactions.

## Features

- Talk directly with Character Mode followers from the in-game conversation UI.
- Let followers respond with awareness of traits, cult details, current events, world state, custom lore, and optional long-term chat memory.
- Choose Short, Medium, or Long reply lengths per character.
- Add player-written lore to individual characters.
- Track tournament matchups, entrant status, and champion history.
- Use included character-safe invocations for cult faith and vanilla role cleanup.
- Configure OpenAI, OpenAI-compatible, Anthropic, Gemini, LM Studio, or Ollama-compatible providers.
- Optionally enable internet access for eligible character replies.

## Installation

Install through Thunderstore Mod Manager or r2modman. The package places the plugin under BepInEx/plugins/COTL_AL_NPCs/ so the mod manager installs it into the profile's BepInEx plugins folder.

## Controls

- F7 while paused: open or close the Invocations menu.
- F8 while paused: open or close the full Tournament Ledger.
- F8 while unpaused: show or hide the current tournament match overlay.
- F9 while paused: open or close the Internet Access panel.

## Configuration

Users provide their own AI provider settings. No API keys are included with the mod, and you should never share files containing your own provider key.

The preferred setup path is the in-game AI Provider Setup prompt. Choose a provider preset, enter your provider details, then use Find, Test & Save Setup. The setup prompt remains visible until a provider and model have passed validation.

Manual configuration uses:

BepInEx/config/COTL_AL_NPCs/AiProvider.json

This hotfix no longer stores pasted provider keys in the mod manager profile. If you used an older release and have BepInEx/config/COTL_AL_NPCs/AiProviderKey.txt, delete that file before sharing or syncing a profile. Rotate the provider key if that profile was already shared.

To reset or change provider setup manually: close the game, open BepInEx/config/COTL_AL_NPCs/ in the modded profile, delete AiProvider.json, AiProviderKey.txt, and LAST_PROVIDER_SETUP_TEST.txt if present, then update or delete the matching Windows user environment variable such as OPENAI_API_KEY, OPENROUTER_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, or AI_PROVIDER_API_KEY.

## AI Provider Setup

Supported provider styles include:

- OpenAI Responses or Chat Completions
- OpenAI-compatible API endpoints
- Anthropic Claude
- Google Gemini
- LM Studio
- Ollama-compatible local endpoints

The sidecar runtime is included in plugins/COTL_AL_NPCs/sidecar/ and is used for provider requests.

## Compatibility

- Cult of the Lamb on Windows
- BepInExPack CultOfTheLamb 5.4.2101
- COTL_API 0.3.3
- .NET 10 runtime for the included sidecar process

## Troubleshooting

- Make sure BepInEx is installed through the mod manager.
- Make sure the mod DLL is enabled in the profile.
- Make sure COTL_API is installed in the same profile.
- If the AI Provider Setup prompt appears, finish provider setup before expecting character replies.
- Check BepInEx logs for plugin errors.
- Check that the sidecar files exist under BepInEx/plugins/COTL_AL_NPCs/sidecar/ after installation.
- Check that AI provider settings are valid.
- Never paste someone else's API key.

## AI-Assisted Creation Disclosure

This mod and Thunderstore package were partially created with the assistance of Generative AI for code changes, refactoring, documentation, and release packaging.

AI model vendor used: OpenAI.

## Credits

- Deamon_Blue
